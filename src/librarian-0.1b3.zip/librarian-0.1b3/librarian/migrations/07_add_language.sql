alter table zipballs add column language varchar;
