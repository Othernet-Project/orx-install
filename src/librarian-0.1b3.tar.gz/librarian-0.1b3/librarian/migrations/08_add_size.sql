alter table zipballs add column size integer;
