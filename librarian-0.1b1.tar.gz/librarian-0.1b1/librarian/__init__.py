__version__ = '0.1b1'
__author__ = 'Outernet Inc <branko@outernet.is>'
