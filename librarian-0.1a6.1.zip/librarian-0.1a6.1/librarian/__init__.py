__version__ = '0.1a6.1'
__author__ = 'Outernet Inc <branko@outernet.is>'
