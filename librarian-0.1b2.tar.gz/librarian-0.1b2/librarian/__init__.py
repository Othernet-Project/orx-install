__version__ = '0.1b2'
__author__ = 'Outernet Inc <branko@outernet.is>'
