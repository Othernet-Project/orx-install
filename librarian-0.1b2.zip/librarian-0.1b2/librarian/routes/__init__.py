from .. import __version__ as _version, __author__ as _author

__version__ = _version
__author__ = _author
